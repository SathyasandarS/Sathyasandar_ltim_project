import multiprocessing

from System.Data.CONSTANTS import *
from System.Node import *


Node(NodeType.Tracking, TRACKPORT).run()
