from System.Data.CONSTANTS import CRASHPORT
from System.Node import *

Node(NodeType.Crashing ,CRASHPORT).run()
