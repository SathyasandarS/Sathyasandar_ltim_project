from System.Data.CONSTANTS import *
from System.Node import *

Node(NodeType.Master,MASTERPORT).run()