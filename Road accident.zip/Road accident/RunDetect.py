from System.Data.CONSTANTS import DETECTPORT
from System.Node import *

Node(NodeType.Detetion,DETECTPORT).run()