import enum


class NodeType(enum.Enum):
   Master = 1
   Detetion = 2
   Tracking = 3
   Crashing = 4